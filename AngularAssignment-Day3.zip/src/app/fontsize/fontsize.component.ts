import { Component } from '@angular/core';

@Component({
  selector: 'app-fontsize',
  templateUrl: './fontsize.component.html',
  styleUrls: ['./fontsize.component.css']
})
export class FontsizeComponent {
   fontsize : number = 12;

   FontSizeIncrease(){
    this.fontsize +=1;
   }

   FontSizeDecrease(){
      this.fontsize -= 1;
    }
   }

