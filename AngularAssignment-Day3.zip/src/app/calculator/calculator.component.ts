import { Component } from '@angular/core';

@Component({
  selector: 'app-calculator',
  templateUrl: './calculator.component.html',
  styleUrls: ['./calculator.component.css']
})
export class CalculatorComponent {

  x: number=0;
  y: number=0;
  result: number=0;
 
  calculate(operation: string) {
     switch (operation) {
       case 'Add':
         this.result = this.x + this.y;
         break;
       case 'Subtract':
         this.result = this.x - this.y;
         break;
       case 'Multiply':
         this.result = this.x * this.y;
         break;
       case 'Divide':
         this.result = this.x / this.y;
         break;
     }
    }

}
