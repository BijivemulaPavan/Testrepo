import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddsubmuldivComponent } from './addsubmuldiv.component';

describe('AddsubmuldivComponent', () => {
  let component: AddsubmuldivComponent;
  let fixture: ComponentFixture<AddsubmuldivComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddsubmuldivComponent]
    });
    fixture = TestBed.createComponent(AddsubmuldivComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
