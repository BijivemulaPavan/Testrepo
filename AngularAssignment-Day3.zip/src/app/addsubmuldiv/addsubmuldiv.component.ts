import { Component } from '@angular/core';

@Component({
  selector: 'app-addsubmuldiv',
  templateUrl: './addsubmuldiv.component.html',
  styleUrls: ['./addsubmuldiv.component.css']
})
export class AddsubmuldivComponent {



}
