import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
 

@Component({
  selector: 'app-login-form',
  templateUrl: './login-form.component.html',
  styleUrls: ['./login-form.component.css']
})
export class LoginFormComponent
{
  loginForm: FormGroup;
  attempts: number = 0;
  maxAttempts: number = 3;
  loginDisabled: boolean = false;
  loginResult: any;

  constructor(private fb: FormBuilder) {
    this.createForm();
  }

  createForm() {
    this.loginForm = this.fb.group({
      username: ['', [Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      const username = this.loginForm.get('username').value;
      const password = this.loginForm.get('password').value;

      // Simulate authentication logic
      if (username === 'pavan' && password === 'pavan666') {
        // Successful login
        this.loginResult = { success: true, message: 'Login successful!' };
        console.log('Login successful!');
      } else {
        // Failed login attempt
        this.attempts++;

        if (this.attempts >= this.maxAttempts) {
          this.loginDisabled = true;
        }

        this.loginResult = { success: false, message: `Login failed. Attempts left: ${this.maxAttempts - this.attempts}` };
        console.log(`Login failed. Attempts left: ${this.maxAttempts - this.attempts}`);
      }
    }
  }
  }