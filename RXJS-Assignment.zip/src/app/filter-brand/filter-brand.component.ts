import { Component,OnInit } from '@angular/core';
import productData from '../product.json';
import { Products } from '../ProductService';
@Component({
  selector: 'app-filter-brand',
  templateUrl: './filter-brand.component.html',
  styleUrls: ['./filter-brand.component.css']
})
export class FilterBrandComponent implements OnInit{
  filterAppleProducts : Products[];
  products: Products[] = productData;
  constructor(){}
  ngOnInit(): void {
    this.filterAppleProducts = this.products.filter((data)=> {
      return data.brand === 'Apple';
    });
  }
}
