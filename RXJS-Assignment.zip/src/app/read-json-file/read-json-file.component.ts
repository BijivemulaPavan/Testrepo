import { Component} from '@angular/core';
import productData from '../product.json';
import { Products } from '../ProductService';

@Component({
  selector: 'app-read-json-file',
  templateUrl: './read-json-file.component.html',
  styleUrls: ['./read-json-file.component.css']
})
export class ReadJsonFileComponent{

  products: Products[] = productData;

}
