import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ReadJsonFileComponent } from './read-json-file.component';

describe('ReadJsonFileComponent', () => {
  let component: ReadJsonFileComponent;
  let fixture: ComponentFixture<ReadJsonFileComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ReadJsonFileComponent]
    });
    fixture = TestBed.createComponent(ReadJsonFileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
