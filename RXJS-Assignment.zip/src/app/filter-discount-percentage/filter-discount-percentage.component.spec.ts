import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FilterDiscountPercentageComponent } from './filter-discount-percentage.component';

describe('FilterDiscountPercentageComponent', () => {
  let component: FilterDiscountPercentageComponent;
  let fixture: ComponentFixture<FilterDiscountPercentageComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FilterDiscountPercentageComponent]
    });
    fixture = TestBed.createComponent(FilterDiscountPercentageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
