import { Component, OnInit } from '@angular/core';
import productData from '../product.json';
import { Products } from '../ProductService';

@Component({
  selector: 'app-filter-discount-percentage',
  templateUrl: './filter-discount-percentage.component.html',
  styleUrls: ['./filter-discount-percentage.component.css']
})
export class FilterDiscountPercentageComponent implements OnInit{
  products: Products[] = productData;
  filterProducts : Products[];
  constructor(){}
  ngOnInit(): void {
    
    this.filterProducts = this.products.filter((data) => {
      return data.discountPercentage > 10 && data.price > 1000;
    });
  }
}


