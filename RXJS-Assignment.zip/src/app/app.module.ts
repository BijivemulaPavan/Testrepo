import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReadJsonFileComponent } from './read-json-file/read-json-file.component';
import { FilterDiscountPercentageComponent } from './filter-discount-percentage/filter-discount-percentage.component';
import { FilterBrandComponent } from './filter-brand/filter-brand.component';

@NgModule({
  declarations: [
    AppComponent,
    ReadJsonFileComponent,
    FilterDiscountPercentageComponent,
    FilterBrandComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
