import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class SmartphoneService {
  private modelsData = [
    {
      model: 'Samsung Galaxy S23',
      colors: ['Cream', 'Green', 'Lavender', 'Phantom Black'],
      prices: ['$799', '$899', '$749'],
    },
    {
      model: 'Galaxy Note20 Ultra',
      colors: ['Mystic Bronze', 'Mystic Black', 'Mystic White'],
      prices: ['$349', '#299', '$329'],
    },
    {
      model: 'Galaxy Z Flip',
      colors: ['Gold', 'Rose Gold', 'Space Gray'],
      prices: ['$999', '$949', '$1299'],
    },
  ];

  getModels() {
    return this.modelsData.map((item) => item.model);
  }

  getColors(model: string) {
    const selectedModel = this.modelsData.find((item) => item.model === model);
    return selectedModel ? selectedModel.colors : [];
  }

  getPrices(model: string, color: string) {
    const selectedModel = this.modelsData.find((item) => item.model === model);
    return selectedModel && selectedModel.colors.includes(color)
      ? selectedModel.prices
      : [];
  }
}
