import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CascadingDropdownSmartphoneComponent } from './cascading-dropdown-smartphone.component';

describe('CascadingDropdownSmartphoneComponent', () => {
  let component: CascadingDropdownSmartphoneComponent;
  let fixture: ComponentFixture<CascadingDropdownSmartphoneComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CascadingDropdownSmartphoneComponent]
    });
    fixture = TestBed.createComponent(CascadingDropdownSmartphoneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
