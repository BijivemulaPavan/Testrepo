import { Component,OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SmartphoneService } from './SmartphoneService';

@Component({
  selector: 'app-cascading-dropdown-smartphone',
  templateUrl: './cascading-dropdown-smartphone.component.html',
  styleUrls: ['./cascading-dropdown-smartphone.component.css']
})
export class CascadingDropdownSmartphoneComponent {

  smartphoneForm: FormGroup;
  models: string[] = [];
  colors: string[] = [];
  prices: string[] = [];

  constructor(
    private fb: FormBuilder,
    private smartphoneService: SmartphoneService
  ) {}

  ngOnInit() {
    this.models = this.smartphoneService.getModels();

    this.smartphoneForm = this.fb.group({
      model: ['', Validators.required],
      color: ['', Validators.required],
      price: ['', Validators.required],
    });

    this.onModelChange();
    this.onColorChange();
  }

  onModelChange() {
    this.smartphoneForm.get('model').valueChanges.subscribe((model) => {
      this.colors = this.smartphoneService.getColors(model);
      this.smartphoneForm.get('color').setValue('');
      this.smartphoneForm.get('price').setValue('');
    });
  }

  onColorChange() {
    this.smartphoneForm.get('color').valueChanges.subscribe((color) => {
      const model = this.smartphoneForm.get('model').value;
      this.prices = this.smartphoneService.getPrices(model, color);
      this.smartphoneForm.get('price').setValue('');
    });
  }

  onSubmit() {
    if (this.smartphoneForm.valid) {
      // Process the form data
      const selectedModel = this.smartphoneForm.get('model').value;
      const selectedColor = this.smartphoneForm.get('color').value;
      const selectedPrice = this.smartphoneForm.get('price').value;

      console.log('Selected Model:', selectedModel);
      console.log('Selected Color:', selectedColor);
      console.log('Selected Price:', selectedPrice);
    }
  }

}
