import { Component , OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-dob-doj-validation',
  templateUrl: './dob-doj-validation.component.html',
  styleUrls: ['./dob-doj-validation.component.css']
})
export class DobDojValidationComponent 
{
  employeeForm: FormGroup;

  constructor(private fb: FormBuilder) {}

  ngOnInit() {
    this.employeeForm = this.fb.group({
      dateOfBirth: ['', [Validators.required]],
      dateOfJoining: ['', [Validators.required]],
    }, { validators: this.validateDOBandDOJ });
  }

  // Custom validator function for DOB and DOJ relationship
  validateDOBandDOJ(formGroup) {
    const dob = formGroup.get('dateOfBirth').value;
    const doj = formGroup.get('dateOfJoining').value;

    if (dob && doj && new Date(dob) > new Date(doj)) {
      formGroup.get('dateOfJoining').setErrors({ invalidDOBandDOJ: true });
    } else {
      formGroup.get('dateOfJoining').setErrors(null);
    }
  }

  // Getter methods for easy access in the template
  get dateOfBirth() {
    return this.employeeForm.get('dateOfBirth');
  }

  get dateOfJoining() {
    return this.employeeForm.get('dateOfJoining');
  }

  // Your form submission logic goes here
  onSubmit() {
    if (this.employeeForm.valid) {
      // Process the form data
    }
  }
}
