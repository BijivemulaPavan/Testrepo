import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DobDojValidationComponent } from './dob-doj-validation.component';

describe('DobDojValidationComponent', () => {
  let component: DobDojValidationComponent;
  let fixture: ComponentFixture<DobDojValidationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DobDojValidationComponent]
    });
    fixture = TestBed.createComponent(DobDojValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
