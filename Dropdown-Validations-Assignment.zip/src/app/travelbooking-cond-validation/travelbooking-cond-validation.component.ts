import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { TravelService } from './travel.service';

@Component({
  selector: 'app-travelbooking-cond-validation',
  templateUrl: './travelbooking-cond-validation.component.html',
  styleUrls: ['./travelbooking-cond-validation.component.css']
})
export class TravelbookingCondValidationComponent {
  travelForm: FormGroup;
  shortlistCountries: string[];
  flights: string[];
  prices: string[];

  constructor(
    private fb: FormBuilder,
    private travelService: TravelService
  ) {}

  ngOnInit() {
    this.shortlistCountries = Object.keys(this.travelService.countryFlightMapping);

    this.travelForm = this.fb.group({
      destination: ['', Validators.required],
      flightName: ['', Validators.required],
      amount: ['', Validators.required],
    });

    this.setupConditionalValidators();
  }

  setupConditionalValidators() {
    this.travelForm.get('destination').valueChanges.subscribe((destination) => {
      const isInternational = this.travelService.isInternational(destination);
      this.flights = this.travelService.getFlights(destination);
      this.prices = [];
      this.travelForm.get('flightName').setValue('');
      this.travelForm.get('amount').setValue('');
    });

    this.travelForm.get('flightName').valueChanges.subscribe((flight) => {
      const destination = this.travelForm.get('destination').value;
      this.prices = this.travelService.getPrices(destination, flight);
      this.travelForm.get('amount').setValue('');
    });
  }

  onSubmit() {
    if (this.travelForm.valid) {
      // Process the form data
      console.log('Form submitted:', this.travelForm.value);
    }
  }
}