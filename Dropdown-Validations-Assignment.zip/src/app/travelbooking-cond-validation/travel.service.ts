import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class TravelService {
  public countryFlightMapping = {
    'USA': { flights: ['Indigo', 'Emirates','AirIndia','JetAirways'], prices: ['$200', '$250','$150'] },
    'Canada': { flights: ['AirIndia', 'Qatar'], prices: ['$180', '$220'] },
    'Germany': { flights: ['Emirates', 'Gofirst','SpiceJet'], prices: ['$300', '$350'] },
    'Dubai': { flights: ['Air Arabia', 'Qatar','Emirates'], prices: ['$270', '$320','$1099'] },
  };

  isInternational(destination: string): boolean {
    return !Object.keys(this.countryFlightMapping).includes(destination);
  }

  getFlights(destination: string): string[] {
    return this.countryFlightMapping[destination]?.flights || [];
  }

  getPrices(destination: string, flight: string): string[] {
    return this.countryFlightMapping[destination]?.prices || [];
  }
}
