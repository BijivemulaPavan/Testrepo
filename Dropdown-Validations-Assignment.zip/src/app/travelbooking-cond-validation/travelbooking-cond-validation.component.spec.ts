import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TravelbookingCondValidationComponent } from './travelbooking-cond-validation.component';

describe('TravelbookingCondValidationComponent', () => {
  let component: TravelbookingCondValidationComponent;
  let fixture: ComponentFixture<TravelbookingCondValidationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TravelbookingCondValidationComponent]
    });
    fixture = TestBed.createComponent(TravelbookingCondValidationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
