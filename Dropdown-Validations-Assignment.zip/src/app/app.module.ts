import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PasswordMatchComponent } from './password-match/password-match.component';
import { ReactiveFormsModule } from '@angular/forms';
import { DobDojValidationComponent } from './dob-doj-validation/dob-doj-validation.component';
import { CascadingDropdownSmartphoneComponent } from './cascading-dropdown-smartphone/cascading-dropdown-smartphone.component';
import { TravelbookingCondValidationComponent } from './travelbooking-cond-validation/travelbooking-cond-validation.component';

@NgModule({
  declarations: [
    AppComponent,
    PasswordMatchComponent,
    DobDojValidationComponent,
    CascadingDropdownSmartphoneComponent,
    TravelbookingCondValidationComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
