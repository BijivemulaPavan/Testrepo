import { Component } from '@angular/core';

@Component({
  selector: 'app-main',
  template: `
    <button (click)="start()">Start</button>
    <button (click)="stop()">Stop</button>
    <p *ngIf="oddNumbers.length > 0">Odd Numbers: {{ oddNumbers.join(', ') }}</p>
    <p *ngIf="evenNumbers.length > 0">Even Numbers: {{ evenNumbers.join(', ') }}</p>
  `
})
export class MainComponent {
  oddNumbers: number[] = [];
  evenNumbers: number[] = [];
  private oddInterval: any;
  private evenInterval: any;
  private oddCounter = 1;
  private evenCounter = 2;

  start() {
    this.oddInterval = setInterval(() => {
      this.oddNumbers.push(this.oddCounter);
      this.oddCounter += 2;
    }, 1000);

    this.evenInterval = setInterval(() => {
      this.evenNumbers.push(this.evenCounter);
      this.evenCounter += 2;
    }, 1000);
  }

  stop() {
    clearInterval(this.oddInterval);
    clearInterval(this.evenInterval);
  }
}