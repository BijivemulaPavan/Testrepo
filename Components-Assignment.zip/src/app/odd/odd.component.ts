import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-odd',
  template: ''
})
export class OddComponent {
  @Output() oddNumberGenerated = new EventEmitter<number>();
}