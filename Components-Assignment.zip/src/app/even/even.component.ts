import { Component, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-even',
  template: ''
})
export class EvenComponent {
  @Output() evenNumberGenerated = new EventEmitter<number>();
}