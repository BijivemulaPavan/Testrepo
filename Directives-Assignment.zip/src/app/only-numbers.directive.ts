import { Directive, ElementRef, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appOnlyNumbers]'
})
export class OnlyNumbersDirective {

  constructor(private el: ElementRef, private renderer: Renderer2) { }

  @HostListener('input', ['$event']) onInput(event: any) {
    const inputElement = this.el.nativeElement;
    const inputValue: string = inputElement.value;
    const newValue: string = inputValue.replace(/[^0-9]/g, ''); 
    this.renderer.setProperty(inputElement, 'value', newValue);
  }

}
