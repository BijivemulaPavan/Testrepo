import { Directive, HostListener, ElementRef } from '@angular/core';

@Directive({
  selector: '[appNoWhiteSpaces]'
})
export class NoWhiteSpacesDirective {

  constructor(private el:ElementRef) { 

  }

  @HostListener('input', ['$event'])onInputChange(event: { stopPropagation: () => void; }){
    const initalValue = this.el.nativeElement.value;
    this.el.nativeElement.value = initalValue.replace(/\s+/g, '');
    if (initalValue !== this.el.nativeElement.value) {
      event.stopPropagation();

    
  }

  }
}