
import { Directive, ElementRef, Input, Renderer2, OnInit } from '@angular/core';

@Directive({
  selector: '[appReadonly]'
})
export class ReadonlyDirective implements OnInit {

  @Input() appReadonly: boolean = true;

  constructor(private el: ElementRef, private renderer: Renderer2) { }

  ngOnInit(): void {
    this.setReadonlyAttribute();
  }

  private setReadonlyAttribute() {
    this.renderer.setProperty(this.el.nativeElement, 'readOnly', this.appReadonly);
  }
}
