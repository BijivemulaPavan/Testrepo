import { ReadonlyDirective } from './readonly.directive';

describe('ReadonlyDirective', () => {
  it('should create an instance', () => {
    const directive = new ReadonlyDirective();
    expect(directive).toBeTruthy();
  });
});
