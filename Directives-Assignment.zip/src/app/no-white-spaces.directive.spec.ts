import { NoWhiteSpacesDirective } from './no-white-spaces.directive';

describe('NoWhiteSpacesDirective', () => {
  it('should create an instance', () => {
    const directive = new NoWhiteSpacesDirective();
    expect(directive).toBeTruthy();
  });
});
