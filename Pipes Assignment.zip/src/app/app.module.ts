import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ReverseStringPipe } from './reverse-string.pipe';
import { CountryComponent } from './country/country.component';
import { SortPipe } from './sort.pipe';
import { TempConversionPipe } from './temp-conversion.pipe';

@NgModule({
  declarations: [
    AppComponent,
    ReverseStringPipe,
    CountryComponent,
    SortPipe,
    TempConversionPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
