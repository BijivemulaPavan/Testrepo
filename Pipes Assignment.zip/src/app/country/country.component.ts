import { Component } from '@angular/core';

@Component({
  selector: 'app-country',
  templateUrl: './country.component.html',
  styleUrls: ['./country.component.css']
})
export class CountryComponent {


  country:string = '';
  countries : string[] = ['INDIA','USA','AUSTRALIA','GERMANY','KUWAIT','EUROPE'];
 sortDirection = 'asc';

 addCountry() {
    if (this.country) {
      this.countries.push(this.country);
      this.country = '';
    }
 }

}
