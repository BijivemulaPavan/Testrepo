import { TempConversionPipe } from './temp-conversion.pipe';

describe('TempConversionPipe', () => {
  it('create an instance', () => {
    const pipe = new TempConversionPipe();
    expect(pipe).toBeTruthy();
  });
});
