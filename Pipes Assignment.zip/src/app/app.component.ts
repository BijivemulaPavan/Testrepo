import { Component } from '@angular/core';
import { ReverseStringPipe } from './reverse-string.pipe';
import { TempConversionPipe } from './temp-conversion.pipe';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Pipes-Assignment';
   
  name:string = 'pavan';

  reversedName: string;

  fahrenheitTemp:number = 42;

  constructor() {
    //For Reverse String
    const a = new ReverseStringPipe();
    this.reversedName = a.transform(this.name);

    

    


  }
}
